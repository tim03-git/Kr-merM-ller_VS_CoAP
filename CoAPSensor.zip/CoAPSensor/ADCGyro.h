volatile int* ADCGyro(void);
