#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <driverlib/debug.h>
#include <driverlib/sysctl.h>
#include <driverlib/gpio.h>
#include <driverlib/adc.h>

#include "CFAF128128B0145T/CFAF128128B0145T.h"
#include "ADCGyro.h"


#ifdef DEBUG
void __error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

volatile int* ADCGyro(void) {
    uint32_t ui32SysClock;
    uint32_t ui32ACCValues[4];  // FIFO size 4 for sequencer 1
    volatile uint32_t ui32AccX;
    volatile uint32_t ui32AccY;
    volatile uint32_t ui32AccZ;


    // Run from the PLL at 120 MHz.
    ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                       SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                                      120000000);


    // Accelerometer pins of Booster Pack and corresponding pins of LaunchPad
    // (Booster pack pos. 1)
    //
    // BoosterPack Fct. BoosterPack Con.    LaunchPad Pin/Fct.  Config Parameter
    // ACC_XOUT         J3-3                PE0 / AIN3          ADC_CTL_CH3
    // ACC_YOUT         J3-4                PE1 / AIN2          ADC_CTL_CH2
    // ACC_ZOUT         J3-5                PE2 / AIN1          ADC_CTL_CH1

    // Enable peripheral ADC0 and GPIOE
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);


    // We configure GPIOE pins 0-2 to be analog inputs (ADC).
    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2);

    // Next, we configure the ADC sequencer. We want to use ADC0, sample
    // sequencer 1, we want the processor to trigger the sequence and we want
    // to use the highest priority.
    ADCSequenceConfigure(ADC0_BASE, 1, ADC_TRIGGER_PROCESSOR, 0);


    // Now we need to configure three steps in the ADC sequencer. The first and
    // second configuration steps will instruct the ADC to sample the X and Y
    // accelerometer outputs, the third configuration step instructs the ADC to
    // sample the Z output, generate an interrupt and also tells the sequencer
    // that this is the final sample in the sequence. Just to keep things
    // simple we won�t actually be interrupting the code, just using the bit
    // to indicate a ready state.
    ADCSequenceStepConfigure(ADC0_BASE, 1, 0, ADC_CTL_CH3);
    ADCSequenceStepConfigure(ADC0_BASE, 1, 1, ADC_CTL_CH2);
    ADCSequenceStepConfigure(ADC0_BASE, 1, 2, ADC_CTL_IE | ADC_CTL_END | ADC_CTL_CH1);

    // Now we can enable ADC sequencer 1. This is the last step to ready the
    // sequencer and ADC before we start them.
    ADCSequenceEnable(ADC0_BASE, 1);

        // The indication that the sequencer and ADC processes are complete will
        // be the ADC interrupt status flag. It�s always good programming
        // practice to make sure that the flag is cleared before writing code
        // that depends on it. This step will also clear the bit each time
        // our code completes the loop.
        ADCIntClearEx(ADC0_BASE, ADC_INT_SS1);

        // Now we can trigger the ADC conversion with software. ADC conversions
        // can be triggered by many other sources.
        ADCProcessorTrigger(ADC0_BASE, 1);

        // We need to wait for the conversion to complete. Obviously, a better
        // way to do this would be to use an actual interrupt, rather than waste
        // CPU cycles waiting, but this is intended to be a simple example of
        // the ADC and sequencer in action.
        while( ADCBusy(ADC0_BASE))
        {
        }

        // When code execution exits the loop in the previous step, we know that
        // the conversion is complete and that we can read the ADC value from
        // the ADC Sample Sequencer 1 FIFO. The function we�ll be using copies
        // data from the specified sample sequencer output FIFO to a buffer in
        // memory. The number of samples available in the hardware FIFO are
        // copied into the buffer, which must be large enough to hold that many
        // samples. This will only return the samples that are presently
        // available, which might not be the entire sample sequence if you
        // attempt to access the FIFO before the conversion is complete.
        ADCSequenceDataGet(ADC0_BASE, 1, ui32ACCValues);

        return ui32ACCValues;
}
